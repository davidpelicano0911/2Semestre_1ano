package aula03.P;
import java.util.Scanner;
import utils.UserInput;

public class ex01 {
    //Escreva um programa que leia do teclado um número inteiro positivo e devolva a soma de
    //todos os números primos até esse valor (inclusive)
    public static void main(String[] args){
        double n = UserInput.positivo("Valor: ");
        double inicial = n;
        int count = 1;
        double soma = n;
        //System.out.println(soma);
        while (true) {
            double valor = UserInput.positivo("Valor: ");
            if (valor == inicial){
                soma += valor;
                count ++;
                break;
            }
            soma += valor;
            count ++;
        }

        System.out.printf("count = %d e soma = %.1f ",count,soma);

    }
}
